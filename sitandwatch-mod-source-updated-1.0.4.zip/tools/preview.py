import struct,sys,numpy as np
from PIL import Image
A='/home/claude/work/proj/src/main/resources/assets/sitandwatch/'
def load(n):
    b=open(A+f'meshes/{n}.bin','rb').read(); o=0
    pc=struct.unpack_from('>i',b,o)[0]; o+=4; V=[]
    for _ in range(pc):
        l=struct.unpack_from('>H',b,o)[0]; o+=2; nm=b[o:o+l].decode(); o+=l
        o+=12; n_=struct.unpack_from('>i',b,o)[0]; o+=4
        V.append(np.frombuffer(b,'>f4',n_*8,o).reshape(-1,8)); o+=n_*32
    return np.concatenate(V)
def render(n,tex,yaw,S=420):
    v=load(n); T=np.asarray(Image.open(A+f'textures/entity/{tex}.png').convert('RGBA'));th,tw=T.shape[:2]
    c=np.cos(yaw);s=np.sin(yaw)
    x=-v[:,0]; y=-v[:,1]+16; z=v[:,2]   # undo vanilla flip: world x=-x_model, y up
    X=x*c+z*s; Z=-x*s+z*c
    sc=S/38; px=X*sc+S/2; py=S-(v[:,1]*0+ (32-v[:,1]))*sc-8
    py=S-((24-v[:,1]))*sc-8
    img=np.full((S,S,4),(40,40,60,255),np.uint8); zb=np.full((S,S),1e9)
    for i in range(0,len(v),3):
        P=np.array([[px[i+k],py[i+k]] for k in range(3)]); zz=Z[i:i+3]; uv=v[i:i+3,3:5]
        # camera looks from -Z? model front is -Z in model space; world z = z => front toward -Z; view from -Z => nearer = smaller Z
        x0,y0=np.floor(P.min(0)).astype(int); x1,y1=np.ceil(P.max(0)).astype(int)
        x0=max(x0,0);y0=max(y0,0);x1=min(x1,S-1);y1=min(y1,S-1)
        if x1<x0 or y1<y0: continue
        d=(P[1,1]-P[2,1])*(P[0,0]-P[2,0])+(P[2,0]-P[1,0])*(P[0,1]-P[2,1])
        if abs(d)<1e-9: continue
        gx,gy=np.meshgrid(np.arange(x0,x1+1)+.5,np.arange(y0,y1+1)+.5)
        a=((P[1,1]-P[2,1])*(gx-P[2,0])+(P[2,0]-P[1,0])*(gy-P[2,1]))/d
        b=((P[2,1]-P[0,1])*(gx-P[2,0])+(P[0,0]-P[2,0])*(gy-P[2,1]))/d
        cc=1-a-b; m=(a>=0)&(b>=0)&(cc>=0)
        if not m.any(): continue
        depth=a*zz[0]+b*zz[1]+cc*zz[2]
        u=(a*uv[0,0]+b*uv[1,0]+cc*uv[2,0]);w=(a*uv[0,1]+b*uv[1,1]+cc*uv[2,1])
        ui=np.clip((u*tw).astype(int),0,tw-1);wi=np.clip((w*th).astype(int),0,th-1)
        col=T[wi,ui]
        sub=zb[y0:y1+1,x0:x1+1]; ok=m&(depth<sub)&(col[...,3]>10)
        sub[ok]=depth[ok]; img[y0:y1+1,x0:x1+1][ok]=col[ok]
    return Image.fromarray(img)
names=[('smug_bro','smug_bro'),('social_villager','social_villager'),('ron_villager','ron_villager'),('the_watcher','the_watcher')]
sheet=Image.new('RGBA',(420*4,420*2))
for i,(n,t) in enumerate(names):
    for j,yaw in enumerate([0,np.pi/2*0+2.4]):
        sheet.paste(render(n,t,yaw),(420*i,420*j))
sheet.convert('RGB').save('/home/claude/work/preview.png')
