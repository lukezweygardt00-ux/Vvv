#!/usr/bin/env python3
"""Convert Blockbench .bbmodel meshes into compact binary mesh assets + PNG textures.
Output coordinate space = vanilla ModelPart space (x=-bbx, y=24-bby, z=bbz, 1 unit = 1/16 block),
uniformly scaled so the model is exactly TARGET_H px (32 = 2 blocks) tall."""
import json, struct, base64, io, sys, math
from PIL import Image
U='/mnt/user-data/uploads/'
OUT='/home/claude/work/proj/src/main/resources/assets/sitandwatch/'
TARGET_H=32.0
PART_RULES=[('Right Upper','rarm'),('Left Upper','larm'),('Center','arms'),('Right Arm','rarm'),('Left Arm','larm'),('Right Leg','rleg'),('Left Leg','lleg'),
            ('Head','head'),('Nose','head'),('Body','body'),('Robe','body')]
def part_of(n):
    for k,v in PART_RULES:
        if k in n: return v
    return 'body'
# pivots in blockbench coords (before transform)
PIVOT={'head':(0,24,0),'body':(0,12,0),'arms':(0,22,0),'rarm':(6,22,0),'larm':(-6,22,0),'rleg':(2,12,0),'lleg':(-2,12,0)}
def convert(src,name,texname,flip=False):
    d=json.load(open(U+src)); R=d['resolution']; W,H=R['width'],R['height']
    ys=[v[1] for e in d['elements'] for v in e['vertices'].values()]
    ymin,ymax=min(ys),max(ys); s=TARGET_H/(ymax-ymin)
    # find group origins (watcher)
    groups={}
    def walk(o):
        for c in o:
            if isinstance(c,dict):
                groups[c['name']]=c['origin']; walk(c.get('children',[]))
    walk(d.get('outliner',[]))
    parts={}
    for e in d['elements']:
        p=part_of(e['name'])
        fx=-1 if flip else 1
        V={k:(v[0]*fx,v[1]-ymin,v[2]*fx) for k,v in e['vertices'].items()}
        tris=parts.setdefault(p,[])
        for f in e['faces'].values():
            vs=f['vertices']; 
            for i in range(1,len(vs)-1):
                tri=[vs[0],vs[i],vs[i+1]]
                tris.append([(V[k],f['uv'][k]) for k in tri])
    def tx(v): return (-v[0]*s, 24.0-v[1]*s, v[2]*s)
    blob=bytearray(); blob+=struct.pack('>i',len(parts)); stats={}
    for p,tris in parts.items():
        pv=PIVOT.get(p,(0,12,0))
        if p in('head',) and 'Head' in groups: pv=(groups['Head'][0]*(-1 if flip else 1),groups['Head'][1]-ymin,groups['Head'][2]*(-1 if flip else 1))
        if name=='the_watcher':
            g={'head':'Head','body':'Body','rarm':'Right Arm','larm':'Left Arm','rleg':'Right Leg','lleg':'Left Leg'}.get(p)
            if g in groups: o=groups[g]; pv=(o[0]*(-1 if flip else 1),o[1]-ymin,o[2]*(-1 if flip else 1))
        pvt=tx(pv)
        # per-vertex normals: area-weighted smooth normals, oriented away from part centroid
        pos=[[tx(v) for v,_ in t] for t in tris]
        cx=sum(x for t in pos for x,_,_ in t)/(3*len(pos)); cy=sum(y for t in pos for _,y,_ in t)/(3*len(pos)); cz=sum(z for t in pos for _,_,z in t)/(3*len(pos))
        fn=[]
        for t in pos:
            a,b,c=t; u=(b[0]-a[0],b[1]-a[1],b[2]-a[2]); w=(c[0]-a[0],c[1]-a[1],c[2]-a[2])
            n=(u[1]*w[2]-u[2]*w[1],u[2]*w[0]-u[0]*w[2],u[0]*w[1]-u[1]*w[0]); fn.append(n)
        # decide global orientation sign by majority outward test
        out=0
        for t,n in zip(pos,fn):
            mx=sum(v[0] for v in t)/3-cx; my=sum(v[1] for v in t)/3-cy; mz=sum(v[2] for v in t)/3-cz
            out+= 1 if n[0]*mx+n[1]*my+n[2]*mz>0 else -1
        sign=1 if out>=0 else -1
        smooth=(name=='the_watcher')
        acc={}
        if smooth:
            for t,n in zip(pos,fn):
                for v in t:
                    k=(round(v[0],3),round(v[1],3),round(v[2],3)); a=acc.setdefault(k,[0,0,0])
                    a[0]+=n[0];a[1]+=n[1];a[2]+=n[2]
        blob+=struct.pack('>H',len(p))+p.encode()+struct.pack('>fff',*pvt)+struct.pack('>i',len(pos)*3)
        for t,n,tri in zip(pos,fn,tris):
            if sign<0: order=[0,2,1]
            else: order=[0,1,2]
            for i in order:
                v=t[i]; uv=tri[i][1]
                if smooth:
                    nn=acc[(round(v[0],3),round(v[1],3),round(v[2],3))]
                else: nn=n
                L=math.sqrt(sum(c*c for c in nn)) or 1
                nx,ny,nz=[sign*c/L for c in nn]
                blob+=struct.pack('>8f',v[0],v[1],v[2],uv[0]/W,uv[1]/H,nx,ny,nz)
        stats[p]=len(pos)
    import os; os.makedirs(OUT+'meshes',exist_ok=True); os.makedirs(OUT+'textures/entity',exist_ok=True)
    open(OUT+f'meshes/{name}.bin','wb').write(bytes(blob))
    t=d['textures'][0]['source']
    if t.startswith('data:'): img=Image.open(io.BytesIO(base64.b64decode(t.split(',',1)[1])))
    else: img=Image.open(t)
    img.convert('RGBA').save(OUT+f'textures/entity/{texname}.png')
    print(name,'scale',round(s,4),'height',TARGET_H,'tex',img.size,stats,len(blob),'bytes')
convert('66cdbe55-smug_bro__1_.bbmodel','smug_bro','smug_bro')
convert('49e78759-smugbroobsessed.bbmodel','social_villager','social_villager')
convert('423ddece-Ron__1_.bbmodel','ron_villager','ron_villager')
convert('9c7ea489-the_watcher_rigged_v2.bbmodel','the_watcher','the_watcher',flip=True)
