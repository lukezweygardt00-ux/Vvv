# Something Wants You To Sit And Watch (Forge 1.20.1)

Fan recreation for Minecraft Forge 1.20.1 (Forge 47.3.0, Java 17, official Mojang mappings).

## Build

The GitHub Actions workflow accepts a source ZIP uploaded to the repository root or a project already extracted there. When a `*mod-source*.zip` is present, it selects the highest versioned `*mod-source*updated-*.zip` archive and extracts it over the checked-out project before building. This means a newly uploaded versioned archive takes priority over older source files already in the repository. The resulting `sitandwatch-1.0.4.jar` is published as the `sitandwatch-jar` Actions artifact.

For a local build, use Gradle 8.1.1 with JDK 17: `gradle build --no-daemon`.

## Story flow

Day 1 begins at the gate of the village built around world spawn. Smug Bro approaches the player and gives a six-stop tour, waiting for the player at each stop rather than completing it automatically. The story clock pauses at the opening-tour stage so the first party night cannot be skipped; Perry does not spawn until the player completes the tour. The mansion is built for the first party night, and Ron is placed at the party so he is visible. On Day 3, if no zipper couch is already present in the player's home, the story places one and hides Ron inside it.

The village houses have exterior-only decoration and empty interiors. Their doors are locked with the message `This is not your house. You cannot enter.` The player's own house remains accessible. Smug Bro's mansion is accessible, but entering its interior triggers his confrontation and escort-out sequence.

The basement trapdoor displays `This is locked.` before Night 4, triggers Smug Bro's confrontation/escort, and cannot be broken to bypass the lock. The Night 4 ending includes the Watcher's existing `Sit in the chair and watch` voice line.

Story commands (operator): `/sitandwatch stage <1-8>`, `/sitandwatch release`, and `/sitandwatch reset`. A new world is the cleanest test. In an existing save, `/sitandwatch reset` resets the story data and rebuilds the village around world spawn, although already-spawned story entities or an older mansion outside the village footprint may remain.

## v1.0.4 changes

- Adds the supplied Ron scream recording and plays it immediately before the explosion.
- Makes Ron shake aggressively using a synchronized whole-model panic animation while he screams.
- Moves the explosion to the end of the full 13.235-second scream.
- Adds a stylized red particle burst around both Ron and the player, in addition to the screen splatter.
- Ends the basement scene with a 1.5-second fade to black, a teleport to the Overworld's shared world spawn (not the player's bed/respawn point), and a 1.5-second fade back in.
- Updates the source-ZIP workflow to choose the highest versioned archive and extract it even if stale source files already exist at the repository root.

## v1.0.3 changes

- Replaced Ron's `gore_burst` explosion sound with the newly supplied OGG audio, keeping the existing sound event and playback code unchanged.

## v1.0.2 changes

- Retained the triangle-to-quad mesh batching fix that corrects the old JAR's smeared/glitched villager textures.
- Corrected the Day 1 tour so Smug Bro walks to the first stop instead of waiting at the plaza, waits for the player at every stop, and does not time out or skip the party sequence after sunset.
- Moved Perry's story spawn until after the tour is complete.
- Built the mansion for Night 1 and put Ron at the party so he is not missing from the first party night.
- Kept village house interiors empty and added locked-door messages, excluding the player's own home.
- Added the early basement lock message, Smug Bro escort behavior, and a break-event lock so the trapdoor cannot be mined around.
- Kept the Night 4 Watcher voice line playing even if the Watcher entity is not resolved at the voice cue.
- Reworked the mansion interior and basement decoration and rebuilt the staircase as a contiguous ascending run.
- Added automatic source-ZIP extraction to `.github/workflows/build.yml`.

## Assets still needed

The original reference video and the separate torch-mod source/JAR were not included with the uploads, so the torch mod has not been merged. Perry's supplied Blockbench model and embedded texture are included below.

### Perry model source

Perry now renders from the supplied Blockbench source model at
`tools/source_models/jerry_normal.bbmodel`. Its embedded 1024x512 texture is
extracted to `src/main/resources/assets/sitandwatch/textures/entity/perry_wolf.png`,
and the model is packed into `src/main/resources/assets/sitandwatch/meshes/perry.bin`.

To regenerate those two runtime assets after editing the Blockbench model, install
Pillow and run `python tools/convert_perry.py` from the project root.

