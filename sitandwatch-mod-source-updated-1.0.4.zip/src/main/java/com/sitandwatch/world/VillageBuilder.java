package com.sitandwatch.world;

import com.sitandwatch.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BedPart;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.block.state.properties.SlabType;
import net.minecraft.world.level.levelgen.Heightmap;

/** Builds the village plaza, gate, farms and 16 exterior-detailed houses around world spawn. */
public class VillageBuilder {
    public static final int R = 34;
    private static final int FLAGS = 2;

    private final ServerLevel level;
    private final BlockPos center;

    private VillageBuilder(ServerLevel level, BlockPos center) {
        this.level = level;
        this.center = center;
    }

    /** Builds the village around the shared world spawn. */
    public static void build(ServerLevel level, StoryData data, BlockPos spawn) {
        int baseY = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, spawn.getX(), spawn.getZ());
        BlockPos center = new BlockPos(spawn.getX(), baseY, spawn.getZ());
        VillageBuilder builder = new VillageBuilder(level, center);

        builder.flatten();
        builder.roads();
        builder.plaza();
        builder.gate();
        builder.lampPosts();
        builder.farm(16, 18);
        builder.farm(-24, 18);

        Object[][] houses = {
                {-28, -12, Direction.SOUTH}, {-20, -12, Direction.SOUTH}, {14, -12, Direction.SOUTH}, {22, -12, Direction.SOUTH},
                {-28, 6, Direction.NORTH}, {-20, 6, Direction.NORTH}, {14, 6, Direction.NORTH}, {22, 6, Direction.NORTH},
                {-11, -27, Direction.EAST}, {-11, -19, Direction.EAST}, {-11, 13, Direction.EAST}, {-11, 21, Direction.EAST},
                {5, -27, Direction.WEST}, {5, -19, Direction.WEST}, {5, 13, Direction.WEST}, {5, 21, Direction.WEST}
        };

        data.lockedVillageDoors.clear();
        for (Object[] house : houses) {
            int x = (Integer) house[0];
            int z = (Integer) house[1];
            Direction facing = (Direction) house[2];
            BlockPos door = builder.house(x, z, facing);
            // This is the player's own house. All other village houses stay locked.
            if (x != -20 || z != 6) data.lockedVillageDoors.add(door.asLong());
        }

        // Player's home: a simple bed, with a clear interior and a door that remains accessible.
        int playerHouseX = -20;
        int playerHouseZ = 6;
        BlockPos bedFoot = center.offset(playerHouseX + 1, 0, playerHouseZ + 3);
        BlockState bed = Blocks.WHITE_BED.defaultBlockState().setValue(HorizontalDirectionalBlock.FACING, Direction.SOUTH);
        level.setBlock(bedFoot, bed.setValue(BedBlock.PART, BedPart.FOOT), FLAGS);
        level.setBlock(bedFoot.relative(Direction.SOUTH), bed.setValue(BedBlock.PART, BedPart.HEAD), FLAGS);
        data.home = bedFoot;

        data.villageCenter = center;
        data.square = center.offset(0, 0, 5);
        data.tour.clear();
        data.tour.add(center.offset(0, 0, R - 6));
        data.tour.add(center.offset(0, 0, 9));
        data.tour.add(center.offset(-17, 0, -4));
        data.tour.add(center.offset(20, 0, 15));
        data.tour.add(center.offset(17, 0, 4));
        data.tour.add(center.offset(0, 0, -R + 6));
        data.tourIdx = 0;
        data.tourArrived = false;
        data.tourComplete = false;
        data.tourClockReset = false;
        data.villageBuilt = true;
        data.setDirty();
    }

    private void set(int x, int y, int z, BlockState state) {
        level.setBlock(center.offset(x, y, z), state, FLAGS);
    }

    private void fill(int x0, int y0, int z0, int x1, int y1, int z1, BlockState state) {
        for (int x = x0; x <= x1; x++) {
            for (int y = y0; y <= y1; y++) {
                for (int z = z0; z <= z1; z++) set(x, y, z, state);
            }
        }
    }

    private static boolean replaceable(BlockState state) {
        return state.isAir() || !state.getFluidState().isEmpty() || state.canBeReplaced()
                || state.is(BlockTags.LEAVES) || state.is(BlockTags.LOGS);
    }

    private void flatten() {
        BlockState air = Blocks.AIR.defaultBlockState();
        BlockState grass = Blocks.GRASS_BLOCK.defaultBlockState();
        BlockState dirt = Blocks.DIRT.defaultBlockState();
        for (int x = -R; x <= R; x++) {
            for (int z = -R; z <= R; z++) {
                for (int y = 0; y <= 14; y++) {
                    BlockPos pos = center.offset(x, y, z);
                    if (!level.getBlockState(pos).isAir()) level.setBlock(pos, air, FLAGS);
                }
                set(x, -1, z, grass);
                for (int y = -2; y >= -14; y--) {
                    BlockPos pos = center.offset(x, y, z);
                    if (replaceable(level.getBlockState(pos))) level.setBlock(pos, dirt, FLAGS);
                    else break;
                }
            }
        }
    }

    private void roads() {
        BlockState path = Blocks.DIRT_PATH.defaultBlockState();
        fill(-R, -1, -1, R, -1, 1, path);
        fill(-1, -1, -R, 1, -1, R, path);
    }

    private void plaza() {
        BlockState brick = Blocks.STONE_BRICKS.defaultBlockState();
        BlockState ring = Blocks.POLISHED_ANDESITE.defaultBlockState();
        for (int x = -7; x <= 7; x++) {
            for (int z = -7; z <= 7; z++) {
                int radiusSquared = x * x + z * z;
                if (radiusSquared <= 49) set(x, -1, z, radiusSquared >= 16 && radiusSquared <= 25 ? ring : brick);
            }
        }
        fill(-1, 0, -1, 1, 0, 1, Blocks.POLISHED_ANDESITE.defaultBlockState());
        set(0, 1, 0, Blocks.GOLD_BLOCK.defaultBlockState());
        BlockState statue = ModBlocks.SMUG_STATUE.get().defaultBlockState()
                .setValue(HorizontalDirectionalBlock.FACING, Direction.SOUTH);
        set(0, 2, 0, statue);
        set(0, 3, 0, statue);
        for (int x : new int[]{-6, 6}) for (int z : new int[]{-6, 6}) post(x, z);
    }

    private void post(int x, int z) {
        fill(x, 0, z, x, 2, z, Blocks.OAK_FENCE.defaultBlockState());
        set(x, 3, z, Blocks.LANTERN.defaultBlockState());
    }

    private void lampPosts() {
        for (int offset : new int[]{-30, -13, 13, 30}) {
            post(offset, -2);
            post(offset, 2);
            post(-2, offset);
            post(2, offset);
        }
    }

    private void gate() {
        BlockState brick = Blocks.STONE_BRICKS.defaultBlockState();
        int z = R - 2;
        for (int x : new int[]{-3, 3}) {
            fill(x, 0, z, x, 4, z, brick);
            set(x, 5, z, Blocks.LANTERN.defaultBlockState());
            set(x, 6, z, Blocks.LANTERN.defaultBlockState());
        }
        fill(-3, 5, z, 3, 5, z, Blocks.STONE_BRICK_SLAB.defaultBlockState());
        set(0, 5, z, Blocks.GOLD_BLOCK.defaultBlockState());
        set(-3, 5, z, brick);
        set(3, 5, z, brick);
    }

    private void farm(int x0, int z0) {
        BlockState farmland = Blocks.FARMLAND.defaultBlockState().setValue(BlockStateProperties.MOISTURE, 7);
        BlockState wheat = Blocks.WHEAT.defaultBlockState().setValue(BlockStateProperties.AGE_7, 7);
        for (int x = 0; x < 9; x++) {
            for (int z = 0; z < 9; z++) {
                boolean border = x == 0 || z == 0 || x == 8 || z == 8;
                if (border) {
                    set(x0 + x, 0, z0 + z, Blocks.OAK_FENCE.defaultBlockState());
                } else if (x == 4 && z == 4) {
                    set(x0 + x, -1, z0 + z, Blocks.WATER.defaultBlockState());
                } else {
                    set(x0 + x, -1, z0 + z, farmland);
                    set(x0 + x, 0, z0 + z, wheat);
                }
            }
        }
        set(x0 + 4, 0, z0, Blocks.AIR.defaultBlockState());
    }

    /** Maps local coordinates (0..6) to a world offset; local z=6 is the front-door wall. */
    private static int[] map(int localX, int localZ, Direction facing) {
        return switch (facing) {
            case NORTH -> new int[]{6 - localX, 6 - localZ};
            case EAST -> new int[]{localZ, 6 - localX};
            case WEST -> new int[]{6 - localZ, localX};
            default -> new int[]{localX, localZ};
        };
    }

    private static Direction localEast(Direction facing) {
        return switch (facing) {
            case NORTH -> Direction.WEST;
            case EAST -> Direction.NORTH;
            case WEST -> Direction.SOUTH;
            default -> Direction.EAST;
        };
    }

    /** A modest house shell with windows, gable roof, porch, lamps and garden details. No interior furniture. */
    private BlockPos house(int x0, int z0, Direction facing) {
        BlockState plank = Blocks.OAK_PLANKS.defaultBlockState();
        BlockState log = Blocks.OAK_LOG.defaultBlockState();
        BlockState cobble = Blocks.COBBLESTONE.defaultBlockState();
        BlockState pane = Blocks.GLASS_PANE.defaultBlockState();
        BlockState spruce = Blocks.SPRUCE_PLANKS.defaultBlockState();
        Direction east = localEast(facing);

        // Foundation and empty interior volume.
        for (int lx = 0; lx <= 6; lx++) {
            for (int lz = 0; lz <= 6; lz++) {
                boolean edge = lx == 0 || lx == 6 || lz == 0 || lz == 6;
                hset(x0, z0, facing, lx, -1, lz, edge ? cobble : plank);
            }
        }

        // Timber-framed exterior walls.
        for (int y = 0; y <= 3; y++) {
            for (int lx = 0; lx <= 6; lx++) {
                for (int lz = 0; lz <= 6; lz++) {
                    boolean edge = lx == 0 || lx == 6 || lz == 0 || lz == 6;
                    if (!edge) continue;
                    boolean corner = (lx == 0 || lx == 6) && (lz == 0 || lz == 6);
                    hset(x0, z0, facing, lx, y, lz, corner ? log : plank);
                }
            }
        }

        // Ceiling and windows.
        for (int lx = 0; lx <= 6; lx++) for (int lz = 0; lz <= 6; lz++) hset(x0, z0, facing, lx, 4, lz, spruce);
        hset(x0, z0, facing, 3, 1, 0, pane);
        hset(x0, z0, facing, 0, 1, 3, pane);
        hset(x0, z0, facing, 6, 1, 3, pane);
        hset(x0, z0, facing, 1, 1, 6, pane);
        hset(x0, z0, facing, 5, 1, 6, pane);

        // Double-height front door.
        int[] localDoor = map(3, 6, facing);
        BlockState door = Blocks.BIRCH_DOOR.defaultBlockState().setValue(DoorBlock.FACING, facing.getOpposite());
        set(x0 + localDoor[0], 0, z0 + localDoor[1], door.setValue(DoorBlock.HALF, DoubleBlockHalf.LOWER));
        set(x0 + localDoor[0], 1, z0 + localDoor[1], door.setValue(DoorBlock.HALF, DoubleBlockHalf.UPPER));
        BlockPos doorPos = center.offset(x0 + localDoor[0], 0, z0 + localDoor[1]);

        // Small front porch and a direct footpath to the village road.
        BlockState slab = Blocks.SPRUCE_SLAB.defaultBlockState().setValue(SlabBlock.TYPE, SlabType.BOTTOM);
        for (int side : new int[]{-2, -1, 0, 1, 2}) {
            int[] p = map(3 + side, 7, facing);
            set(x0 + p[0], -1, z0 + p[1], Blocks.COBBLESTONE.defaultBlockState());
            set(x0 + p[0], 0, z0 + p[1], slab);
        }
        for (int side : new int[]{-2, 2}) {
            int[] p = map(3 + side, 7, facing);
            set(x0 + p[0], 0, z0 + p[1], Blocks.OAK_FENCE.defaultBlockState());
            set(x0 + p[0], 1, z0 + p[1], Blocks.LANTERN.defaultBlockState());
        }
        for (int k = 1; k <= 12; k++) {
            int px = x0 + localDoor[0] + facing.getStepX() * k;
            int pz = z0 + localDoor[1] + facing.getStepZ() * k;
            if (Math.abs(px) <= 1 || Math.abs(pz) <= 1) break;
            set(px, -1, pz, Blocks.DIRT_PATH.defaultBlockState());
        }

        // Stepped spruce gable roof: solid blocks rather than inverted stair pieces.
        for (int lz = -1; lz <= 7; lz++) {
            for (int i = 0; i <= 3; i++) {
                hset(x0, z0, facing, -1 + i, 4 + i, lz, spruce);
                hset(x0, z0, facing, 7 - i, 4 + i, lz, spruce);
            }
            hset(x0, z0, facing, 3, 7, lz, spruce);
        }
        for (int lz : new int[]{0, 6}) {
            for (int lx = 1; lx <= 5; lx++) hset(x0, z0, facing, lx, 5, lz, spruce);
            for (int lx = 2; lx <= 4; lx++) hset(x0, z0, facing, lx, 6, lz, spruce);
        }

        // Exterior-only garden details. Keep all decorations beyond the porch so the house
        // interior is a completely empty shell (apart from the player's own bed).
        for (int side : new int[]{-2, 2}) {
            int[] bush = map(3 + side, 8, facing);
            set(x0 + bush[0], 0, z0 + bush[1], Blocks.OAK_LEAVES.defaultBlockState().setValue(LeavesBlock.PERSISTENT, true));
            int[] flower = map(3 + side, 9, facing);
            set(x0 + flower[0], 0, z0 + flower[1], side < 0 ? Blocks.POPPY.defaultBlockState() : Blocks.DANDELION.defaultBlockState());
        }
        return doorPos;
    }

    private void hset(int x0, int z0, Direction facing, int localX, int y, int localZ, BlockState state) {
        int[] mapped = map(localX, localZ, facing);
        set(x0 + mapped[0], y, z0 + mapped[1], state);
    }
}
