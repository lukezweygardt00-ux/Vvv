package com.sitandwatch.world;

import com.sitandwatch.entity.*;
import com.sitandwatch.network.*;
import com.sitandwatch.registry.ModEntities;
import com.sitandwatch.registry.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.LogicalSide;
import org.joml.Vector3f;

import javax.annotation.Nullable;
import java.util.List;
import java.util.UUID;

/** Drives the whole multi-day escalation: Day 1 (hook) -> Night 4 (basement). */
public class StoryManager {
    private static final int PH_APPROACH = 0, PH_TOUR = 1, PH_SITE = 2;
    // 13.235 s OGG at 20 ticks/second rounds to 265 ticks.
    private static final int RON_SCREAM_START = 480;
    private static final int RON_SCREAM_TICKS = 265;
    private static final int RON_EXPLOSION_TICK = RON_SCREAM_START + RON_SCREAM_TICKS;
    private static final int END_FADE_TICKS = 30;

    // ------------------------------------------------------------------ events
    @SubscribeEvent
    public void onLevelTick(TickEvent.LevelTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.side != LogicalSide.SERVER || !(e.level instanceof ServerLevel sl)) return;
        if (sl.dimension() != Level.OVERWORLD) return;
        StoryData d = data(sl);
        if (!d.started) {
            if (!sl.players().isEmpty()) begin(sl, d, sl.players().get(0));
            return;
        }
        ServerPlayer p = d.player == null ? null : (ServerPlayer) sl.getPlayerByUUID(d.player);
        if (p == null) return;
        if (d.climaxStarted && !d.climaxDone) { tickClimax(sl, d, p); return; }
        if (sl.getGameTime() % 20 != 0) return;
        try {
            tickStory(sl, d, p);
        } catch (Exception ex) {
            com.mojang.logging.LogUtils.getLogger().error("Story tick failed", ex);
        }
    }

    // ------------------------------------------------------------------ public helpers
    public static StoryData data(ServerLevel sl) {
        return sl.getServer().overworld().getDataStorage().computeIfAbsent(StoryData::load, StoryData::new, StoryData.NAME);
    }

    public static Stage stage(ServerLevel sl, StoryData d) {
        long t = sl.getDayTime();
        long day = t / 24000L - d.startDay;
        // Never let sleeping, commands, or a fast clock skip the opening tour and its party setup.
        if (d.started && !d.tourComplete) return Stage.DAY1;
        boolean night = (t % 24000L) >= 12500L;
        if (day < 0) day = 0;
        if (day >= 4) return Stage.POST;
        return Stage.values()[(int) (day * 2 + (night ? 1 : 0))];
    }

    public static boolean isTrapdoorLocked(ServerLevel sl, BlockPos pos) {
        StoryData d = data(sl);
        if (d.lockedTrapdoors.contains(pos.asLong())) return true;
        return d.trapdoor != null && d.trapdoor.equals(pos) && !stage(sl, d).atLeast(Stage.NIGHT4);
    }

    public static boolean isVillageDoorLocked(ServerLevel sl, BlockPos lowerDoorPos) {
        return data(sl).lockedVillageDoors.contains(lowerDoorPos.asLong());
    }

    /** Called when the player tries the basement trapdoor before the final night. */
    public static void onBasementDoorAttempt(ServerLevel sl, BlockPos pos, ServerPlayer player) {
        StoryData d = data(sl);
        if (stage(sl, d).atLeast(Stage.NIGHT4)) return;
        SmugBroEntity smug = find(sl, d.smug, SmugBroEntity.class);
        BlockPos destination = d.square != null ? d.square : (d.doorPos != null
                ? d.doorPos.relative(Direction.SOUTH, 4) : pos.relative(Direction.SOUTH, 4));
        beginSmugEscort(sl, d, player, smug, destination,
                "Smug Bro: The basement is off-limits. Come with me.");
    }

    public static boolean isLocked(ServerPlayer p) {
        StoryData d = data(p.serverLevel());
        return d.climaxStarted && !d.climaxDone && p.getUUID().equals(d.player);
    }

    public static boolean noSleep(ServerLevel sl) {
        StoryData d = data(sl);
        if (!d.started) return false;
        Stage s = stage(sl, d);
        return s == Stage.NIGHT3 || s == Stage.NIGHT4;
    }

    public static void onFanHurt(ServerLevel sl) {
        StoryData d = data(sl);
        if (d.mobStarted && !d.mobDone) { d.mobHits++; d.setDirty(); }
    }

    /** Called by the couch block when right-clicked while zipped. Ejects Ron and starts the frame-up. */
    public static void onCouchUnzipped(ServerLevel sl, BlockPos pos, Direction facing) {
        StoryData d = data(sl);
        if (d.couchUnzipped) return;
        d.couchUnzipped = true;
        d.unzipTick = sl.getGameTime();
        d.dismissive = true;
        RonEntity ron = find(sl, d.ron, RonEntity.class);
        if (ron != null) {
            BlockPos front = pos.relative(facing);
            ron.setInvisible(false);
            ron.setNoAi(true);
            ron.setPoseState(StoryVillager.P_FAINTED);
            ron.teleportTo(front.getX() + 0.5, front.getY(), front.getZ() + 0.5);
        }
        SmugBroEntity smug = find(sl, d.smug, SmugBroEntity.class);
        if (smug != null) {
            smug.setGesture(StoryVillager.G_LAUGH, 100);
            smug.talk();
            BlockPos sq = d.square != null ? d.square : (d.partyPos != null ? d.partyPos : pos);
            smug.setMoveTarget(Vec3.atBottomCenterOf(sq), 1.7);
        }
        for (SocialVillagerEntity f : fans(sl, pos, 120)) { f.setObsessed(false); f.setGesture(StoryVillager.G_NONE, 0); }
        d.setDirty();
    }

    public static void release(ServerLevel sl, StoryData d, @Nullable ServerPlayer p) {
        d.climaxDone = true;
        d.lockedTrapdoors.clear();
        if (d.trapdoor != null) {
            BlockState s = sl.getBlockState(d.trapdoor);
            if (s.getBlock() instanceof TrapDoorBlock) sl.setBlock(d.trapdoor, s.setValue(TrapDoorBlock.OPEN, true), 3);
        }
        if (p != null) {
            p.stopRiding();
            ModNetwork.sendTo(p, new CameraLockPacket(false, 0, 0));
            ModNetwork.sendTo(p, new EffectPacket(EffectPacket.AMBIENCE_STOP, 0));
        }
        Entity w = d.watcher == null ? null : sl.getEntity(d.watcher);
        if (w != null) w.discard();
        d.setDirty();
    }

    // ------------------------------------------------------------------ setup
    private void begin(ServerLevel sl, StoryData d, ServerPlayer p) {
        d.started = true;
        d.startDay = sl.getDayTime() / 24000L;
        d.player = p.getUUID();
        BlockPos respawn = p.getRespawnPosition();
        d.home = respawn != null ? respawn : p.blockPosition();
        d.phaseStart = sl.getGameTime();
        d.perrySpawned = false;
        d.tourComplete = false;
        d.tourClockReset = false;
        d.setDirty();
    }

    // ------------------------------------------------------------------ per-second story logic
    private void tickStory(ServerLevel sl, StoryData d, ServerPlayer p) {
        Stage st = stage(sl, d);
        // Start the multi-day story clock only after the tour finishes. This guarantees the
        // mansion party is the first Night 1 beat even if the tour ran through sunset.
        if (d.tourComplete && !d.tourClockReset) {
            d.startDay = sl.getDayTime() / 24000L;
            d.tourClockReset = true;
            d.setDirty();
            st = stage(sl, d);
        }
        long now = sl.getGameTime();
        long tod = sl.getDayTime() % 24000L;
        if (st == Stage.POST || d.climaxDone) return;

        // Night 4: Smug Bro vanishes, trapdoor is left open, wait for the player to descend.
        if (st == Stage.NIGHT4) {
            ensureMansion(sl, d, p);
            if (!d.night4Prepared) {
                SmugBroEntity s = find(sl, d.smug, SmugBroEntity.class);
                if (s != null) s.discard();
                if (d.trapdoor != null) {
                    BlockState ts = sl.getBlockState(d.trapdoor);
                    if (ts.getBlock() instanceof TrapDoorBlock) sl.setBlock(d.trapdoor, ts.setValue(TrapDoorBlock.OPEN, true), 3);
                }
                for (SocialVillagerEntity f : fans(sl, p.blockPosition(), 120)) { f.setObsessed(false); f.clearMoveTarget(); }
                d.night4Prepared = true;
                d.setDirty();
            }
            if (d.basementMin != null && d.basementMax != null
                    && new AABB(d.basementMin, d.basementMax.offset(1, 1, 1)).contains(p.position())) {
                startClimax(sl, d, p);
            }
            return;
        }

        if (!ensureVillage(sl, d, p)) return; // wait until the spawn chunks are loaded
        if (!d.fansConverted) convertVillagers(sl, d, p);
        if (!d.smugSpawned && d.fansConverted) spawnSmug(sl, d, p);
        SmugBroEntity smug = find(sl, d.smug, SmugBroEntity.class);
        if (smug == null) {
            if (d.smugSpawned && d.fansConverted) spawnSmug(sl, d, p);
            return;
        }
        List<SocialVillagerEntity> fans = fans(sl, p.blockPosition(), 120);

        // Older builds spawned Perry as soon as the story started. Remove that early instance
        // from an existing save and let the completed tour create the correctly timed one.
        if (!d.tourComplete && d.perrySpawned) {
            PerryEntity earlyPerry = find(sl, d.perry, PerryEntity.class);
            if (earlyPerry != null) earlyPerry.discard();
            d.perry = null;
            d.perrySpawned = false;
            d.perryBetrayed = false;
            d.setDirty();
        }

        // The tour is a required opening beat. Keep it running across the day/night boundary,
        // and do not start the mansion party or spawn Perry until Smug Bro reaches the final stop.
        boolean runningOpeningTour = !d.tourComplete && d.phase <= PH_TOUR;
        if (runningOpeningTour) {
            day1(sl, d, p, smug, fans, now, tod);
            if (!d.tourComplete) return;
        }
        // Also cover saves upgraded after the final tour stop but before the delayed Perry spawn.
        if (d.tourComplete && !d.perrySpawned) spawnPerryAfterTour(sl, d, p);

        // Night 1 is the first party night: create the mansion and party location before Ron spawns.
        if (st.atLeast(Stage.NIGHT1)) {
            ensureSite(sl, d);
            ensureMansion(sl, d, p);
        }
        if (st.atLeast(Stage.NIGHT1) && !d.ronSpawned) spawnRonAtParty(sl, d, p);
        if (d.mansionBuilt && d.perrySpawned && !d.perryBetrayed) {
            PerryEntity perry = find(sl, d.perry, PerryEntity.class);
            if (perry != null) {
                perry.betray();
                d.perryBetrayed = true;
                d.setDirty();
            }
        }
        checkSmugHouseIntrusion(sl, d, p, smug, now);
        // Villagers wave at the player on Day 1 (and stay friendly until the frame-up)
        if (!d.dismissive) waveAtPlayer(fans, p);

        switch (st) {
            case DAY1 -> { if (!runningOpeningTour) day1(sl, d, p, smug, fans, now, tod); }
            case NIGHT1, NIGHT2 -> party(sl, d, smug, fans, now);
            case DAY2 -> day2(sl, d, p, smug, fans, now, tod);
            case DAY3 -> day3(sl, d, p, smug, fans, now);
            case NIGHT3 -> night3(sl, d, p, smug, fans, now);
            case DAY4 -> day4(sl, d, smug, fans);
            default -> { }
        }
        if (d.dismissive && !(st == Stage.NIGHT3 && d.mobStarted && !d.mobDone)) shunPlayer(p, fans);
        if (d.couchUnzipped && !d.ronWoke && now - d.unzipTick > 200) {
            RonEntity ron = find(sl, d.ron, RonEntity.class);
            if (ron != null) { ron.setNoAi(false); ron.setPoseState(StoryVillager.P_SHIVER); }
            d.ronWoke = true;
            d.setDirty();
        }
        // Apply the escort target after the stage logic, which otherwise overwrites Smug Bro's
        // movement command every story tick (for example, the party's circle target).
        tickSmugEscort(sl, d, p, smug, now);
    }

    // ---- Day 1: the hook
    private void day1(ServerLevel sl, StoryData d, ServerPlayer p, SmugBroEntity smug, List<SocialVillagerEntity> fans, long now, long tod) {
        double dist = smug.distanceTo(p);
        switch (d.phase) {
            case PH_APPROACH -> {
                smug.setMoveTarget(p.position(), 1.1);
                if (dist < 4.5) {
                    smug.clearMoveTarget();
                    smug.setGesture(StoryVillager.G_WAVE, 70);
                    smug.talk();
                    d.phase = PH_TOUR;
                    d.phaseStart = now;
                }
            }
            case PH_TOUR -> {
                if (!d.tour.isEmpty()) {
                    tourStep(sl, d, p, smug, now);
                } else {
                    if (dist > 14) { smug.clearMoveTarget(); smug.getLookControl().setLookAt(p); }
                    else if (!smug.hasMoveTarget() && !fans.isEmpty()) {
                        SocialVillagerEntity f = fans.get(sl.random.nextInt(fans.size()));
                        smug.setMoveTarget(f.position().add(1.5, 0, 0), 1.0);
                        smug.setGesture(sl.random.nextBoolean() ? StoryVillager.G_POINT : StoryVillager.G_WAVE, 50);
                        smug.talk();
                    }
                }
                if (dist < 5 && now - d.lastGrab > 1500 && sl.random.nextInt(10) == 0) {
                    d.lastGrab = now;
                    smug.setGesture(StoryVillager.G_GRAB, 25);
                    p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 3));
                    ModNetwork.sendTo(p, new NudgePacket(18f, 6f));
                }
            }
            default -> {
                ensureSite(sl, d);
                spawnPerryAfterTour(sl, d, p);
                if (d.site != null) {
                    smug.setMoveTarget(Vec3.atBottomCenterOf(d.site.offset(8, 0, MansionBuilder.D + 4)), 1.0);
                    if (smug.tickCount % 200 < 20) smug.setGesture(StoryVillager.G_FLEX, 60);
                }
            }
        }
    }

    /** Smug Bro walks to each stop; he waits there until the player catches up. */
    private void tourStep(ServerLevel sl, StoryData d, ServerPlayer p, SmugBroEntity smug, long now) {
        if (d.tourIdx >= d.tour.size()) {
            d.tourComplete = true;
            d.phase = PH_SITE;
            ensureSite(sl, d);
            spawnPerryAfterTour(sl, d, p);
            d.setDirty();
            return;
        }

        Vec3 target = Vec3.atBottomCenterOf(d.tour.get(d.tourIdx));
        if (!d.tourArrived) {
            if (smug.position().distanceToSqr(target) <= 9.0) {
                smug.clearMoveTarget();
                smug.getLookControl().setLookAt(p);
                if (p.position().distanceToSqr(target) <= 18.0 * 18.0) {
                    d.tourArrived = true;
                    d.tourStopTick = now + 160;
                    smug.setGesture(d.tourIdx % 2 == 0 ? StoryVillager.G_POINT : StoryVillager.G_WAVE, 70);
                    smug.talk();
                    d.setDirty();
                } else if (smug.tickCount % 100 < 20) {
                    smug.setGesture(StoryVillager.G_WAVE, 40);
                }
            } else {
                // The first stop is the gate where the player starts. Never wait for the player
                // before Smug Bro has even walked there, or the whole tour deadlocks.
                smug.setMoveTarget(target, 1.0);
            }
        } else if (now >= d.tourStopTick) {
            d.tourIdx++;
            d.tourArrived = false;
            d.setDirty();
        }
    }

    /** Builds the village at world spawn and starts the tour from its gate. */
    private boolean ensureVillage(ServerLevel sl, StoryData d, ServerPlayer p) {
        if (d.villageBuilt) return true;
        BlockPos spawn = sl.getSharedSpawnPos();
        BlockPos min = spawn.offset(-VillageBuilder.R, 0, -VillageBuilder.R);
        BlockPos max = spawn.offset(VillageBuilder.R, 0, VillageBuilder.R);
        forceLoadArea(sl, min, max);
        VillageBuilder.build(sl, d, spawn);
        if (d.home != null) p.setRespawnPosition(Level.OVERWORLD, d.home, 0.0f, true, false);
        BlockPos gate = d.villageCenter.offset(0, 0, VillageBuilder.R - 4);
        p.teleportTo(gate.getX() + 0.5, gate.getY(), gate.getZ() + 0.5);
        return true;
    }

    private static void forceLoadArea(ServerLevel sl, BlockPos min, BlockPos max) {
        int minX = min.getX() >> 4;
        int maxX = max.getX() >> 4;
        int minZ = min.getZ() >> 4;
        int maxZ = max.getZ() >> 4;
        for (int x = minX; x <= maxX; x++) {
            for (int z = minZ; z <= maxZ; z++) sl.getChunk(x, z);
        }
    }

    // ---- Night 1 / Night 2: fans circle Smug Bro at the mansion (the happy theme plays client-side)
    private void party(ServerLevel sl, StoryData d, SmugBroEntity smug, List<SocialVillagerEntity> fans, long now) {
        if (d.partyPos == null) return;
        Vec3 c = Vec3.atBottomCenterOf(d.partyPos);
        smug.setMoveTarget(c, 1.2);
        RonEntity ron = find(sl, d.ron, RonEntity.class);
        if (ron != null && !ron.isBefriended()) {
            Vec3 ronSpot = groundVec(sl, c.add(-3.5, 0, 2.0));
            ron.setPoseState(StoryVillager.P_SHIVER);
            ron.setMoveTarget(ronSpot, 0.85);
            ron.getLookControl().setLookAt(smug);
        }
        if (now % 160 < 20) smug.setGesture(StoryVillager.G_FLEX, 60);
        circle(sl, fans, c, 5.0, now, true);
        if (!fans.isEmpty() && sl.random.nextInt(3) == 0) fans.get(sl.random.nextInt(fans.size())).cheer();
        sl.sendParticles(ParticleTypes.NOTE, c.x, c.y + 2.4, c.z, 3, 2.5, 0.6, 2.5, 1.0);
    }

    // ---- Day 2: alienation and the party
    private void day2(ServerLevel sl, StoryData d, ServerPlayer p, SmugBroEntity smug, List<SocialVillagerEntity> fans, long now, long tod) {
        RonEntity ron = find(sl, d.ron, RonEntity.class);
        if (d.partyPos == null) return;
        Vec3 pc = Vec3.atBottomCenterOf(d.partyPos);
        switch (d.lurePhase) {
            case 0 -> {
                party(sl, d, smug, fans, now);
                if (ron != null && (ron.isBefriended() || tod > 8000)) { d.lurePhase = 1; d.setDirty(); }
            }
            case 1 -> { // Smug Bro comes to the player and lures them toward the party
                smug.setMoveTarget(p.position(), 1.2);
                if (ron != null && !ron.isBefriended()) { ron.setPoseState(StoryVillager.P_NORMAL); ron.setMoveTarget(p.position(), 1.1); }
                circle(sl, fans, pc, 5.0, now, true);
                if (smug.distanceTo(p) < 5) {
                    smug.setGesture(StoryVillager.G_WAVE, 60);
                    smug.talk();
                    d.lurePhase = 2;
                    d.setDirty();
                }
            }
            case 2 -> {
                circle(sl, fans, pc, 5.0, now, true);
                if (p.distanceToSqr(pc) > 225) { smug.setMoveTarget(p.position(), 1.2); }
                else smug.setMoveTarget(pc, 1.0);
                if (ron != null && !ron.isBefriended()) ron.setMoveTarget(p.position(), 1.1);
                if (p.distanceToSqr(pc) < 49) trap(sl, d, p, ron);
            }
            case 3 -> trapTick(sl, d, p, smug, ron, fans, now);
            default -> party(sl, d, smug, fans, now);
        }
    }

    private void trap(ServerLevel sl, StoryData d, ServerPlayer p, @Nullable RonEntity ron) {
        d.lurePhase = 3;
        d.partyStart = sl.getGameTime();
        d.ringCenter = p.blockPosition();
        BlockPos c = d.ringCenter;
        for (int dx = -4; dx <= 4; dx++) for (int dz = -4; dz <= 4; dz++) {
            double r = Math.sqrt(dx * dx + dz * dz);
            if (r < 3.0 || r > 4.0) continue;
            for (int dy = 0; dy <= 2; dy++) {
                BlockPos bp = c.offset(dx, dy, dz);
                if (sl.getBlockState(bp).isAir()) { sl.setBlock(bp, Blocks.BARRIER.defaultBlockState(), 2); d.barrier.add(bp); }
            }
        }
        if (ron != null) { ron.clearMoveTarget(); ron.teleportTo(p.getX() + 1.5, p.getY(), p.getZ()); }
        d.setDirty();
    }

    private void trapTick(ServerLevel sl, StoryData d, ServerPlayer p, SmugBroEntity smug, @Nullable RonEntity ron, List<SocialVillagerEntity> fans, long now) {
        Vec3 c = Vec3.atBottomCenterOf(d.ringCenter != null ? d.ringCenter : p.blockPosition());
        smug.setMoveTarget(c.add(0, 0, -5.5), 1.2);
        smug.setGesture(StoryVillager.G_LAUGH, 30);
        circle(sl, fans, c, 6.5, now, false);
        for (SocialVillagerEntity f : fans) {
            f.setGesture(StoryVillager.G_LAUGH, 30);
            f.getLookControl().setLookAt(p);
            if (sl.random.nextInt(4) == 0) f.playSound(SoundEvents.VILLAGER_CELEBRATE, 1.0f, 1.0f);
        }
        if (ron != null) { ron.setGesture(StoryVillager.G_LAUGH, 30); ron.getLookControl().setLookAt(p); }
        if (now - d.partyStart > 320) {
            for (BlockPos bp : d.barrier) if (sl.getBlockState(bp).is(Blocks.BARRIER)) sl.setBlock(bp, Blocks.AIR.defaultBlockState(), 3);
            d.barrier.clear();
            d.lurePhase = 4;
            d.partyDone = true;
            if (ron != null) { ron.setGesture(StoryVillager.G_NONE, 0); ron.setPoseState(StoryVillager.P_SHIVER); }
            d.setDirty();
        }
    }

    // ---- Day 3: the frame-up
    private void day3(ServerLevel sl, StoryData d, ServerPlayer p, SmugBroEntity smug, List<SocialVillagerEntity> fans, long now) {
        if (!d.ronStuffed) {
            placeCouch(sl, d);
            RonEntity ron = find(sl, d.ron, RonEntity.class);
            if (ron != null && d.couch != null) {
                ron.clearMoveTarget();
                ron.setNoAi(true);
                ron.setPoseState(StoryVillager.P_FAINTED);
                ron.setInvisible(true);
                ron.teleportTo(d.couch.getX() + 0.5, d.couch.getY(), d.couch.getZ() + 0.5);
            }
            d.ronStuffed = true;
            d.setDirty();
        }
        if (d.couchUnzipped) {
            if (smug.distanceToSqr(Vec3.atBottomCenterOf(d.square != null ? d.square : smug.blockPosition())) < 9) smug.clearMoveTarget();
            return;
        }
        if (d.couch == null) return;
        Vec3 front = Vec3.atBottomCenterOf(d.couch.relative(d.couchFacing, 2));
        switch (d.day3Phase) {
            case 0 -> {
                smug.setMoveTarget(p.position(), 1.2);
                if (smug.distanceTo(p) < 5) { smug.setGesture(StoryVillager.G_WAVE, 50); smug.talk(); d.day3Phase = 1; d.setDirty(); }
            }
            case 1 -> {
                if (smug.distanceTo(p) > 12) { smug.clearMoveTarget(); smug.getLookControl().setLookAt(p); }
                else smug.setMoveTarget(front, 1.0);
                if (smug.position().distanceToSqr(front) < 4) { d.day3Phase = 2; d.setDirty(); }
            }
            default -> {
                smug.clearMoveTarget();
                smug.getLookControl().setLookAt(p);
                smug.setGesture(StoryVillager.G_POINT, 30);
                if (now % 100 == 0) smug.talk();
            }
        }
        if (d.partyPos != null) circle(sl, fans, Vec3.atBottomCenterOf(d.partyPos), 5.0, now, true);
    }

    // ---- Night 3: the angry mob
    private void night3(ServerLevel sl, StoryData d, ServerPlayer p, SmugBroEntity smug, List<SocialVillagerEntity> fans, long now) {
        if (d.home == null || d.mobDone) { shunPlayer(p, fans); return; }
        if (!d.mobStarted) { d.mobStarted = true; d.mobStart = now; d.mobHits = 0; d.setDirty(); }
        BlockPos door = findDoor(sl, d.home);
        Vec3 c = Vec3.atBottomCenterOf(door != null ? door : d.home);
        smug.setMoveTarget(c.add(0, 0, 2.5), 1.3);
        smug.setGesture(StoryVillager.G_ANGRY, 30);
        circle(sl, fans, c, 3.5, now, false);
        for (SocialVillagerEntity f : fans) {
            f.setGesture(StoryVillager.G_ANGRY, 30);
            f.setObsessed(false);
            if (sl.random.nextInt(3) == 0) f.playSound(SoundEvents.VILLAGER_NO, 1.0f, 0.8f);
        }
        if (now % 40 == 0) {
            sl.playSound(null, door != null ? door : d.home, SoundEvents.ZOMBIE_ATTACK_WOODEN_DOOR, SoundSource.HOSTILE, 1.6f, 0.9f);
        }
        if (d.mobHits >= 3) {
            d.mobDone = true;
            for (SocialVillagerEntity f : fans) f.setGesture(StoryVillager.G_NONE, 0);
            smug.clearMoveTarget();
            d.setDirty();
        }
    }

    // ---- Day 4: Smug Bro waits upstairs
    private void day4(ServerLevel sl, StoryData d, SmugBroEntity smug, List<SocialVillagerEntity> fans) {
        if (d.smugRoom != null && smug.distanceToSqr(Vec3.atBottomCenterOf(d.smugRoom)) > 4) {
            smug.teleportTo(d.smugRoom.getX() + 0.5, d.smugRoom.getY(), d.smugRoom.getZ() + 0.5);
        }
        smug.clearMoveTarget();
        for (SocialVillagerEntity f : fans) f.setGesture(StoryVillager.G_NONE, 0);
    }

    // ------------------------------------------------------------------ Night 4 climax
    private void startClimax(ServerLevel sl, StoryData d, ServerPlayer p) {
        d.climaxStarted = true;
        d.climaxTick = 0;
        if (d.chair == null || d.ronSpot == null) { d.climaxDone = true; return; }
        RonEntity ron = find(sl, d.ron, RonEntity.class);
        if (ron == null) {
            ron = spawn(sl, ModEntities.RON.get(), Vec3.atBottomCenterOf(d.ronSpot));
            if (ron != null) d.ron = ron.getUUID();
        }
        if (ron != null) {
            ron.setInvisible(false);
            ron.setNoAi(true);
            ron.setPoseState(StoryVillager.P_TRAPPED);
            ron.teleportTo(d.ronSpot.getX() + 0.5, d.ronSpot.getY(), d.ronSpot.getZ() + 0.5);
            ron.setYRot(0f); ron.yBodyRot = 0f; ron.yHeadRot = 0f;
        }
        if (d.trapdoor != null) {
            BlockState s = sl.getBlockState(d.trapdoor);
            if (s.getBlock() instanceof TrapDoorBlock) sl.setBlock(d.trapdoor, s.setValue(TrapDoorBlock.OPEN, false), 3);
            d.lockedTrapdoors.add(d.trapdoor.asLong());
            sl.playSound(null, d.trapdoor, SoundEvents.WOODEN_TRAPDOOR_CLOSE, SoundSource.BLOCKS, 3.0f, 0.5f);
            sl.playSound(null, d.trapdoor, SoundEvents.ANVIL_LAND, SoundSource.BLOCKS, 1.0f, 0.4f);
        }
        ModNetwork.sendTo(p, new CameraLockPacket(true, p.getYRot(), p.getXRot()));
        d.setDirty();
    }

    private void tickClimax(ServerLevel sl, StoryData d, ServerPlayer p) {
        int t = d.climaxTick++;
        if (p.isDeadOrDying()) { release(sl, d, p); return; }
        BlockPos cb = d.chair;
        Vec3 c = new Vec3(cb.getX() + 0.5, cb.getY(), cb.getZ() + 0.5);
        WatcherEntity w = find(sl, d.watcher, WatcherEntity.class);

        if (t == 30) {
            Vec3 look = Vec3.directionFromRotation(0, p.getYRot());
            Vec3 b = p.position().subtract(look.scale(0.9));
            sl.playSound(null, b.x, b.y + 1.5, b.z, ModSounds.WATCHER_BREATHING.get(), SoundSource.HOSTILE, 3.0f, 0.9f);
        }
        if (t == 80) {
            Vec3 look = Vec3.directionFromRotation(0, p.getYRot());
            Vec3 b = p.position().subtract(look.scale(1.1));
            WatcherEntity nw = spawn(sl, ModEntities.WATCHER.get(), b);
            if (nw != null) { face(nw, p.getYRot()); d.watcher = nw.getUUID(); w = nw; }
        }
        if (t == 170) { // forcibly seat the player in the chair, staring straight ahead
            p.teleportTo(sl, c.x, c.y + 0.1, c.z, 180f, 0f);
            ChairSeatEntity.seat(sl, cb, p);
            ModNetwork.sendTo(p, new CameraLockPacket(true, 180f, 3f));
            if (w != null) { w.teleportTo(c.x, c.y, c.z + 1.2); face(w, 180f); }
            sl.playSound(null, c.x, c.y + 1.5, c.z + 1.0, ModSounds.WATCHER_BREATHING.get(), SoundSource.HOSTILE, 3.0f, 0.8f);
        }
        if (w != null && t >= 220 && t < 290) { // the Watcher steps out from behind and creeps to the front-left
            float f = (t - 220) / 70f;
            Vec3 p0 = new Vec3(c.x, c.y, c.z + 1.2), p1 = new Vec3(c.x - 1.3, c.y, c.z + 0.1), p2 = new Vec3(c.x - 0.45, c.y, c.z - 0.95);
            moveWatcher(w, bezier(p0, p1, p2, f), p.getEyePosition());
        }
        if (t == 300) {
            ModNetwork.sendTo(p, new SubtitlePacket("sitandwatch.subtitle.sit", 90, true));
            Vec3 voice = w != null ? w.position() : c.add(-0.45, 0, -0.95);
            sl.playSound(null, voice.x, voice.y + 1.6, voice.z,
                    ModSounds.SIT_IN_THE_CHAIR.get(), SoundSource.HOSTILE, 3.0f, 1.0f);
        }
        if (w != null && t >= 380 && t < 460) { // backs away and fades out of view
            float f = (t - 380) / 80f;
            Vec3 a = new Vec3(c.x - 0.45, c.y, c.z - 0.95), b = new Vec3(c.x - 1.6, c.y, c.z - 5.5);
            moveWatcher(w, a.lerp(b, f), p.getEyePosition());
        }
        if (w != null && t == 460) {
            sl.sendParticles(ParticleTypes.LARGE_SMOKE, w.getX(), w.getY() + 1.0, w.getZ(), 40, 0.4, 0.9, 0.4, 0.02);
            w.discard();
            d.watcher = null;
        }
        if (t == RON_SCREAM_START) {
            RonEntity ron = find(sl, d.ron, RonEntity.class);
            Vec3 screamAt = ron != null ? ron.position() : Vec3.atBottomCenterOf(d.ronSpot);
            if (ron != null) {
                ron.clearMoveTarget();
                ron.setNoAi(true);
                ron.setDeltaMovement(Vec3.ZERO);
                ron.setPoseState(StoryVillager.P_PANIC);
            }
            sl.playSound(null, screamAt.x, screamAt.y + 1.0, screamAt.z,
                    ModSounds.RON_SCREAM.get(), SoundSource.HOSTILE, 3.2f, 1.0f);
        }
        if (t == RON_EXPLOSION_TICK) explodeRon(sl, d, p);
        if (t == 800) ModNetwork.sendTo(p, new EffectPacket(EffectPacket.AMBIENCE_START, 0));
        if (t == 1100) ModNetwork.sendTo(p, new SubtitlePacket("sitandwatch.subtitle.continued", 200, false));

        // End on a true world-spawn return: fade out, teleport while fully black, fade in.
        if (t == 1500) ModNetwork.sendTo(p, new EffectPacket(EffectPacket.FADE_OUT, END_FADE_TICKS));
        if (t == 1530) {
            p.stopRiding();
            BlockPos worldSpawn = sl.getSharedSpawnPos();
            p.teleportTo(sl, worldSpawn.getX() + 0.5, worldSpawn.getY(), worldSpawn.getZ() + 0.5,
                    p.getYRot(), p.getXRot());
            ModNetwork.sendTo(p, new EffectPacket(EffectPacket.FADE_IN, END_FADE_TICKS));
        }
        if (t >= 1560) release(sl, d, p);
    }

    private void explodeRon(ServerLevel sl, StoryData d, ServerPlayer p) {
        RonEntity ron = find(sl, d.ron, RonEntity.class);
        Vec3 pos = ron != null ? ron.position() : Vec3.atBottomCenterOf(d.ronSpot);
        sl.playSound(null, pos.x, pos.y + 1, pos.z, ModSounds.GORE_BURST.get(), SoundSource.HOSTILE, 3.0f, 1.0f);
        sl.sendParticles(new DustParticleOptions(new Vector3f(0.55f, 0.02f, 0.02f), 2.5f), pos.x, pos.y + 1.0, pos.z, 300, 0.6, 0.8, 0.6, 0.35);
        sl.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.REDSTONE_BLOCK.defaultBlockState()), pos.x, pos.y + 1.0, pos.z, 150, 0.5, 0.7, 0.5, 0.3);

        // A stylized red particle burst also surrounds the seated player, paired with the screen splatter.
        sl.sendParticles(new DustParticleOptions(new Vector3f(0.72f, 0.015f, 0.025f), 1.65f),
                p.getX(), p.getY() + 0.95, p.getZ(), 120, 0.72, 0.9, 0.72, 0.18);
        sl.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.REDSTONE_BLOCK.defaultBlockState()),
                p.getX(), p.getY() + 0.95, p.getZ(), 55, 0.55, 0.8, 0.55, 0.22);

        for (int i = 0; i < 10; i++) {
            ItemEntity it = new ItemEntity(sl, pos.x, pos.y + 1.0, pos.z, new ItemStack(i % 3 == 0 ? Items.BONE : Items.ROTTEN_FLESH));
            it.setDeltaMovement((sl.random.nextDouble() - 0.5) * 0.6, 0.25 + sl.random.nextDouble() * 0.3, (sl.random.nextDouble() - 0.5) * 0.6);
            it.setPickUpDelay(32767);
            sl.addFreshEntity(it);
        }
        if (ron != null) ron.discard();
        ModNetwork.sendTo(p, new EffectPacket(EffectPacket.BLOOD, 260));
    }

    private static void moveWatcher(WatcherEntity w, Vec3 pos, Vec3 lookAt) {
        w.setPos(pos.x, pos.y, pos.z);
        float yaw = (float) (Mth.atan2(lookAt.z - pos.z, lookAt.x - pos.x) * (180.0 / Math.PI)) - 90.0f;
        face(w, yaw);
    }

    private static void face(WatcherEntity w, float yaw) {
        w.setYRot(yaw); w.yRotO = yaw; w.yBodyRot = yaw; w.yBodyRotO = yaw; w.yHeadRot = yaw; w.yHeadRotO = yaw;
        w.setXRot(0f);
    }

    private static Vec3 bezier(Vec3 a, Vec3 b, Vec3 c, float t) { return a.lerp(b, t).lerp(b.lerp(c, t), t); }

    // ------------------------------------------------------------------ crowd behaviour
    private static void circle(ServerLevel sl, List<SocialVillagerEntity> fans, Vec3 c, double r, long now, boolean obsessed) {
        int n = Math.max(1, fans.size());
        for (int i = 0; i < fans.size(); i++) {
            SocialVillagerEntity f = fans.get(i);
            double a = Math.PI * 2 * i / n + (obsessed ? now * 0.012 : 0);
            f.setObsessed(obsessed);
            f.setMoveTarget(c.add(Math.cos(a) * r, 0, Math.sin(a) * r), 1.1);
            f.getLookControl().setLookAt(c.x, c.y + 1.6, c.z);
        }
    }

    private static void waveAtPlayer(List<SocialVillagerEntity> fans, ServerPlayer p) {
        for (SocialVillagerEntity f : fans) {
            if (f.distanceToSqr(p) < 144 && f.getGesture() == StoryVillager.G_NONE && f.getRandom().nextInt(5) == 0 && f.hasLineOfSight(p)) {
                f.setGesture(StoryVillager.G_WAVE, 50);
                f.getLookControl().setLookAt(p);
            }
        }
    }

    private static void shunPlayer(ServerPlayer p, List<SocialVillagerEntity> fans) {
        for (SocialVillagerEntity f : fans) {
            if (f.distanceToSqr(p) < 100) {
                Vec3 away = f.position().subtract(p.position()).normalize().scale(7).add(f.position());
                f.setMoveTarget(away, 1.0);
                f.getLookControl().setLookAt(away.x, f.getEyeY(), away.z);
                if (f.getRandom().nextInt(8) == 0) f.playSound(SoundEvents.VILLAGER_NO, 1.0f, 1.0f);
            }
        }
    }

    // ------------------------------------------------------------------ spawning / world helpers
    private void convertVillagers(ServerLevel sl, StoryData d, ServerPlayer p) {
        List<Villager> vs = sl.getEntitiesOfClass(Villager.class, p.getBoundingBox().inflate(64));
        long elapsed = sl.getGameTime() - d.phaseStart;
        boolean village = d.villageBuilt && d.villageCenter != null;
        if (!village && vs.isEmpty() && elapsed < 4000) return; // wait until the player is near a village
        Vec3 center = village ? Vec3.atBottomCenterOf(d.villageCenter) : p.position();
        if (!village && !vs.isEmpty()) {
            double sx = 0, sz = 0;
            for (Villager v : vs) { sx += v.getX(); sz += v.getZ(); }
            center = new Vec3(sx / vs.size(), p.getY(), sz / vs.size());
        }
        int count = 0;
        for (Villager v : vs) {
            SocialVillagerEntity s = spawn(sl, ModEntities.SOCIAL_VILLAGER.get(), v.position());
            if (s != null) { s.setYRot(v.getYRot()); count++; }
            v.discard();
        }
        int target = village ? 16 : 6;
        for (int i = count; i < target; i++) {
            Vec3 pos;
            if (village) {
                double a = i * (Math.PI * 2.0 / target);
                double rad = 3.5 + (i % 2) * 2.0;
                pos = groundVec(sl, center.add(Math.cos(a) * rad, 0, Math.sin(a) * rad));
            } else {
                pos = groundVec(sl, center.add(sl.random.nextInt(9) - 4, 0, sl.random.nextInt(9) - 4));
            }
            spawn(sl, ModEntities.SOCIAL_VILLAGER.get(), pos);
        }
        d.square = village ? d.villageCenter.offset(0, 0, 5) : BlockPos.containing(center);
        d.fansConverted = true;
        d.setDirty();
    }

    private void spawnRonAtParty(ServerLevel sl, StoryData d, ServerPlayer p) {
        if (d.ronSpawned) return;
        Vec3 center = d.partyPos != null ? Vec3.atBottomCenterOf(d.partyPos) : p.position();
        Vec3 spot = d.partyPos != null ? center.add(-3.5, 0, 2.0) : p.position().add(4, 0, 3);
        RonEntity ron = spawn(sl, ModEntities.RON.get(), groundVec(sl, spot));
        if (ron != null) {
            ron.setPoseState(StoryVillager.P_SHIVER);
            ron.setYRot(90f);
            d.ron = ron.getUUID();
            d.ronSpawned = true;
            d.setDirty();
        }
    }

    private void spawnPerryAfterTour(ServerLevel sl, StoryData d, ServerPlayer p) {
        if (!d.tourComplete || d.perrySpawned) return;
        PerryEntity perry = spawn(sl, ModEntities.PERRY.get(), groundVec(sl, p.position().add(2.5, 0, 2.5)));
        if (perry != null) {
            d.perry = perry.getUUID();
            d.perrySpawned = true;
            d.setDirty();
        }
    }

    private static void beginSmugEscort(ServerLevel sl, StoryData d, ServerPlayer p,
                                        @Nullable SmugBroEntity smug, BlockPos destination, String line) {
        if (smug == null || d.smugEscortActive) return;
        d.smugEscortActive = true;
        d.smugEscortStart = sl.getGameTime();
        d.smugEscortDestination = destination.immutable();
        smug.clearMoveTarget();
        smug.setGesture(StoryVillager.G_ANGRY, 90);
        smug.talk();
        smug.setMoveTarget(p.position(), 1.35);
        p.displayClientMessage(Component.literal(line), false);
        d.setDirty();
    }

    private void tickSmugEscort(ServerLevel sl, StoryData d, ServerPlayer p, SmugBroEntity smug, long now) {
        if (!d.smugEscortActive) return;
        if (smug == null) {
            d.smugEscortActive = false;
            d.smugEscortDestination = null;
            d.setDirty();
            return;
        }
        smug.setMoveTarget(p.position(), 1.35);
        if (smug.distanceToSqr(p) <= 9.0 || now - d.smugEscortStart >= 120) {
            BlockPos destination = d.smugEscortDestination != null ? d.smugEscortDestination
                    : (d.doorPos != null ? d.doorPos.relative(Direction.SOUTH, 4) : p.blockPosition());
            Vec3 exit = groundVec(sl, Vec3.atBottomCenterOf(destination));
            p.teleportTo(exit.x, exit.y, exit.z);
            p.displayClientMessage(Component.literal("Smug Bro escorts you away."), true);
            p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 30, 1));
            smug.clearMoveTarget();
            smug.setGesture(StoryVillager.G_POINT, 60);
            d.smugEscortActive = false;
            d.smugEscortDestination = null;
            d.lastSmugEscort = now;
            d.setDirty();
        }
    }

    private void checkSmugHouseIntrusion(ServerLevel sl, StoryData d, ServerPlayer p, SmugBroEntity smug, long now) {
        if (!d.mansionBuilt || d.site == null || d.climaxStarted || d.smugEscortActive || now - d.lastSmugEscort < 100) return;
        AABB interior = new AABB(d.site.offset(1, 0, 1), d.site.offset(MansionBuilder.W - 1, 10, MansionBuilder.D - 1));
        if (!interior.contains(p.position())) return;
        BlockPos exit = d.doorPos != null ? d.doorPos.relative(Direction.SOUTH, 4) : d.site.offset(8, 0, MansionBuilder.D + 4);
        beginSmugEscort(sl, d, p, smug, exit, "Smug Bro: This is my house. You need to leave.");
    }

    private void spawnSmug(ServerLevel sl, StoryData d, ServerPlayer p) {
        double a = sl.random.nextDouble() * Math.PI * 2;
        Vec3 pos = groundVec(sl, p.position().add(Math.cos(a) * 14, 0, Math.sin(a) * 14));
        if (d.villageBuilt && d.villageCenter != null) {
            // he waits in the plaza, next to his statue, ready to give the tour
            pos = groundVec(sl, Vec3.atBottomCenterOf(d.villageCenter).add(0, 0, 4.5));
        }
        SmugBroEntity s = spawn(sl, ModEntities.SMUG_BRO.get(), pos);
        if (s != null) { d.smug = s.getUUID(); d.smugSpawned = true; d.phase = PH_APPROACH; d.phaseStart = sl.getGameTime(); d.setDirty(); }
    }

    private void ensureSite(ServerLevel sl, StoryData d) {
        if (d.site != null) return;
        if (d.villageBuilt && d.villageCenter != null) {
            // just past the north end of the village's main road, door facing the village
            // (the builder clears 5 blocks beyond its footprint, so it stays 6 blocks clear of the village edge)
            BlockPos vc = d.villageCenter;
            d.site = new BlockPos(vc.getX() - 8, vc.getY(), vc.getZ() - VillageBuilder.R - MansionBuilder.D - 6);
            d.partyPos = d.site.offset(8, 0, MansionBuilder.D + 4);
            d.setDirty();
            return;
        }
        if (d.home == null) return;
        // put the mansion 4 blocks past the first window we can find so it blocks the view
        Direction dir = Direction.EAST;
        search:
        for (Direction dd : Direction.Plane.HORIZONTAL) {
            for (int i = 1; i <= 6; i++) {
                BlockState s = sl.getBlockState(d.home.relative(dd, i).above());
                if (s.getBlock() instanceof GlassBlock || s.getBlock() instanceof IronBarsBlock) { dir = dd; break search; }
            }
        }
        int hw = MansionBuilder.W / 2, hd = MansionBuilder.D / 2;
        int cx = d.home.getX() + dir.getStepX() * (4 + (dir.getAxis() == Direction.Axis.X ? hw : hd));
        int cz = d.home.getZ() + dir.getStepZ() * (4 + (dir.getAxis() == Direction.Axis.X ? hw : hd));
        int y = sl.getHeight(Heightmap.Types.WORLD_SURFACE, cx, cz);
        d.site = new BlockPos(cx - hw, Math.max(y, sl.getMinBuildHeight() + 12), cz - hd);
        d.partyPos = d.site.offset(8, 0, MansionBuilder.D + 4);
        d.setDirty();
    }

    private void ensureMansion(ServerLevel sl, StoryData d, ServerPlayer p) {
        if (d.mansionBuilt) return;
        ensureSite(sl, d);
        if (d.site == null) return;
        // The mansion is the Night 1 party location, so it must exist even when the player
        // is still exploring elsewhere in the village.
        forceLoadArea(sl, d.site.offset(-3, 0, -3), d.site.offset(MansionBuilder.W + 2, 0, MansionBuilder.D + 5));
        MansionBuilder.build(sl, d, d.site);
    }

    private void placeCouch(ServerLevel sl, StoryData d) {
        if (d.home == null) return;
        BlockPos found = null;
        for (BlockPos bp : BlockPos.betweenClosed(d.home.offset(-10, -3, -10), d.home.offset(10, 3, 10))) {
            BlockState s = sl.getBlockState(bp);
            if (s.getBlock() instanceof com.sitandwatch.block.ZipperCouchBlock) { found = bp.immutable(); break; }
        }
        Direction face = Direction.NORTH;
        if (found == null) {
            outer:
            for (int r = 1; r <= 7; r++) {
                for (int dx = -r; dx <= r; dx++) for (int dz = -r; dz <= r; dz++) {
                    if (Math.max(Math.abs(dx), Math.abs(dz)) != r) continue;
                    BlockPos bp = d.home.offset(dx, 0, dz);
                    if (sl.getBlockState(bp).isAir() && sl.getBlockState(bp.above()).isAir() && sl.getBlockState(bp.below()).isFaceSturdy(sl, bp.below(), Direction.UP)) {
                        found = bp;
                        face = Math.abs(dx) > Math.abs(dz) ? (dx > 0 ? Direction.WEST : Direction.EAST) : (dz > 0 ? Direction.NORTH : Direction.SOUTH);
                        break outer;
                    }
                }
            }
            if (found == null) found = d.home.east(2);
            sl.setBlock(found, com.sitandwatch.registry.ModBlocks.ZIPPER_COUCH.get().defaultBlockState().setValue(HorizontalDirectionalBlock.FACING, face), 3);
        } else {
            face = sl.getBlockState(found).getValue(HorizontalDirectionalBlock.FACING);
        }
        BlockState s = sl.getBlockState(found);
        sl.setBlock(found, s.setValue(com.sitandwatch.block.ZipperCouchBlock.HAS_ZIPPER, true).setValue(com.sitandwatch.block.ZipperCouchBlock.UNZIPPED, false), 3);
        d.couch = found;
        d.couchFacing = face;
        d.couchPlacedFlag = true; d.setDirty();
    }

    @Nullable
    private static BlockPos findDoor(ServerLevel sl, BlockPos home) {
        for (BlockPos bp : BlockPos.betweenClosed(home.offset(-8, -2, -8), home.offset(8, 3, 8))) {
            if (sl.getBlockState(bp).getBlock() instanceof DoorBlock) return bp.immutable();
        }
        return null;
    }

    private static Vec3 cornerNear(ServerLevel sl, Vec3 around, int radius) {
        for (int i = 0; i < 40; i++) {
            Vec3 g = groundVec(sl, around.add(sl.random.nextInt(radius * 2) - radius, 0, sl.random.nextInt(radius * 2) - radius));
            BlockPos bp = BlockPos.containing(g);
            for (Direction dd : Direction.Plane.HORIZONTAL) {
                if (sl.getBlockState(bp.relative(dd)).canOcclude() && sl.getBlockState(bp.relative(dd).above()).canOcclude()) return g;
            }
        }
        return groundVec(sl, around.add(radius, 0, 0));
    }

    private static Vec3 groundVec(ServerLevel sl, Vec3 v) {
        BlockPos bp = sl.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, BlockPos.containing(v));
        return new Vec3(v.x, bp.getY(), v.z);
    }

    @Nullable
    private static <T extends net.minecraft.world.entity.Mob> T spawn(ServerLevel sl, EntityType<T> type, Vec3 pos) {
        T e = type.create(sl);
        if (e == null) return null;
        e.moveTo(pos.x, pos.y, pos.z, sl.random.nextFloat() * 360f, 0f);
        e.setPersistenceRequired();
        sl.addFreshEntity(e);
        return e;
    }

    @Nullable
    private static <T extends Entity> T find(ServerLevel sl, @Nullable UUID id, Class<T> cls) {
        if (id == null) return null;
        Entity e = sl.getEntity(id);
        return cls.isInstance(e) && e.isAlive() ? cls.cast(e) : null;
    }

    private static List<SocialVillagerEntity> fans(ServerLevel sl, BlockPos around, int r) {
        return sl.getEntitiesOfClass(SocialVillagerEntity.class, new AABB(around).inflate(r), Entity::isAlive);
    }
}
