package com.sitandwatch.entity;

import com.sitandwatch.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraftforge.network.NetworkHooks;

import java.util.List;

/** Invisible 'seat' the player rides while sitting in the chair. */
public class ChairSeatEntity extends Entity {
    public ChairSeatEntity(EntityType<? extends ChairSeatEntity> type, Level level) {
        super(type, level);
        this.noPhysics = true;
        this.setInvisible(true);
    }

    /** Create a seat at the chair and mount the player. Returns the seat (or null on failure). */
    public static ChairSeatEntity seat(Level level, BlockPos chair, Player player) {
        List<ChairSeatEntity> existing = level.getEntitiesOfClass(ChairSeatEntity.class, new net.minecraft.world.phys.AABB(chair).inflate(0.5));
        for (ChairSeatEntity e : existing) {
            if (!e.isVehicle()) { player.startRiding(e, true); return e; }
            return null;
        }
        ChairSeatEntity seat = new ChairSeatEntity(ModEntities.CHAIR_SEAT.get(), level);
        seat.setPos(chair.getX() + 0.5, chair.getY() + 0.85, chair.getZ() + 0.5);
        level.addFreshEntity(seat);
        player.startRiding(seat, true);
        return seat;
    }

    @Override
    public void tick() {
        super.tick();
        if (!level().isClientSide && this.getPassengers().isEmpty() && this.tickCount > 5) {
            this.discard();
        }
    }

    @Override
    public double getPassengersRidingOffset() {
        return 0.0;
    }

    @Override
    protected void defineSynchedData() { }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) { }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) { }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
