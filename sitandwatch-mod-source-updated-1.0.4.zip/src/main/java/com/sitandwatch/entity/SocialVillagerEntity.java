package com.sitandwatch.entity;

import com.sitandwatch.registry.ModSounds;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;

/** Overhauled villager / Smug Bro fan. Uses normal villager noises. */
public class SocialVillagerEntity extends StoryVillager {
    public SocialVillagerEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
    }

    @Nullable @Override protected SoundEvent talkSound() { return SoundEvents.VILLAGER_AMBIENT; }

    /** Plays the fan cheer clip at this villager. */
    public void cheer() {
        this.level().playSound(null, this.blockPosition(), ModSounds.OBSESSED_CHEER.get(), net.minecraft.sounds.SoundSource.NEUTRAL, 1.0f, 1.0f);
    }
}
