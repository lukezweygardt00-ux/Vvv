package com.sitandwatch.client;

import com.sitandwatch.network.EffectPacket;
import com.sitandwatch.registry.ModSounds;
import net.minecraft.client.Minecraft;
import net.minecraft.sounds.SoundSource;

/** Client-side story state mirrored from the server through packets. */
public class ClientState {
    public static boolean locked;
    public static float lockYaw, lockPitch;

    public static String subKey = "";
    public static int subTicks, subMax;
    public static boolean subDistorted;

    public static int bloodTicks, bloodMax;
    public static boolean ambience;
    private static LoopingSound ambienceSound;

    // 0=clear, 1=fading to black, 2=holding black, 3=fading back in.
    private static int fadePhase, fadeTicks, fadeMax;

    public static void setLock(boolean l, float yaw, float pitch) {
        locked = l;
        lockYaw = yaw;
        lockPitch = pitch;
        Minecraft mc = Minecraft.getInstance();
        if (l && mc.player != null) {
            mc.player.setYRot(yaw);
            mc.player.setXRot(pitch);
            mc.player.yRotO = yaw;
            mc.player.xRotO = pitch;
        }
    }

    public static void showSubtitle(String key, int ticks, boolean distorted) {
        subKey = key;
        subTicks = subMax = ticks;
        subDistorted = distorted;
    }

    public static void nudge(float dYaw, float dPitch) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        mc.player.setYRot(mc.player.getYRot() + dYaw);
        mc.player.setXRot(mc.player.getXRot() + dPitch);
    }

    public static void effect(int type, int arg) {
        switch (type) {
            case EffectPacket.BLOOD -> { bloodTicks = bloodMax = Math.max(1, arg); }
            case EffectPacket.AMBIENCE_START -> {
                ambience = true;
                ambienceSound = new LoopingSound(ModSounds.AMBIENCE_LOOP.get(), SoundSource.AMBIENT, () -> ambience, () -> 0.9f);
                Minecraft.getInstance().getSoundManager().play(ambienceSound);
            }
            case EffectPacket.AMBIENCE_STOP -> ambience = false;
            case EffectPacket.FADE_OUT -> {
                fadeMax = fadeTicks = Math.max(1, arg);
                fadePhase = 1;
            }
            case EffectPacket.FADE_IN -> {
                fadeMax = fadeTicks = Math.max(1, arg);
                fadePhase = 3;
            }
            default -> { }
        }
    }

    public static void tick() {
        if (subTicks > 0) subTicks--;
        if (bloodTicks > 0) bloodTicks--;
        if (fadeTicks > 0) {
            fadeTicks--;
            if (fadeTicks == 0) {
                if (fadePhase == 1) fadePhase = 2;
                else if (fadePhase == 3) fadePhase = 0;
            }
        }
    }

    /** Alpha for the full-screen black transition, rendered above the normal HUD. */
    public static float fadeAlpha() {
        return switch (fadePhase) {
            case 1 -> 1.0f - fadeTicks / (float) Math.max(1, fadeMax);
            case 2 -> 1.0f;
            case 3 -> fadeTicks / (float) Math.max(1, fadeMax);
            default -> 0.0f;
        };
    }
}
